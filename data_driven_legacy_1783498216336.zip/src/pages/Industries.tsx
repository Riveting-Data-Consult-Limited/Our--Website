import React from 'react';
import { motion } from 'framer-motion';
import { 
  Building2, 
  Users, 
  School, 
  Landmark, 
  Rocket, 
  HeartHandshake,
  CheckCircle
} from 'lucide-react';

const industries = [
  {
    title: 'Startups & Entrepreneurs',
    icon: Rocket,
    desc: 'Helping early-stage ventures build solid digital foundations, scale operations, and prepare for investment through structured documentation and branding.',
    features: ['Branding & Pitch Decks', 'MVP Development', 'Business Registration']
  },
  {
    title: 'SMEs',
    icon: Building2,
    desc: 'Driving efficiency in established small and medium enterprises through process automation, digital marketing, and data-driven decision making.',
    features: ['Process Automation', 'Digital Marketing', 'Data Analytics']
  },
  {
    title: 'Government & Public Sector',
    icon: Landmark,
    desc: 'Partnering with government agencies to implement digital transformation initiatives, B2G programs, and transparency tools.',
    features: ['e-Governance Tools', 'Policy Support', 'Tech Implementation']
  },
  {
    title: 'NGOs & Dev Partners',
    icon: HeartHandshake,
    desc: 'Supporting non-profits with digital skills training, impact measurement tools, and technological infrastructure for social good programs.',
    features: ['Impact Tracking', 'Program Management', 'Capacity Building']
  },
  {
    title: 'Educational Institutions',
    icon: School,
    desc: 'Developing EdTech solutions, curriculum development, and teacher training programs for schools and vocational centers.',
    features: ['LMS Implementation', 'Digital Curriculum', 'Skills Development']
  },
  {
    title: 'Youth & Empowerment Programs',
    icon: Users,
    desc: 'Designing and executing large-scale workforce development and digital literacy programs for youth and marginalized groups.',
    features: ['Skill Assessments', 'Placement Pathways', 'Training Design']
  }
];

export default function Industries() {
  return (
    <div className="pt-20">
      <section className="py-24 bg-gradient-to-b from-blue-50 to-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-4xl">
            <h1 className="text-4xl md:text-6xl font-bold text-slate-900 mb-8 leading-tight">
              Specialized Solutions for <span className="text-blue-600">Diverse Sectors</span>
            </h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              We understand that every sector has unique challenges. Our approach is tailored to meet the specific regulatory, operational, and impact requirements of your industry.
            </p>
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {industries.map((industry, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:shadow-blue-500/5 transition-all group"
              >
                <div className="bg-slate-50 w-20 h-20 rounded-3xl flex items-center justify-center mb-8 group-hover:bg-blue-600 group-hover:text-white transition-all">
                  <industry.icon size={40} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-6">{industry.title}</h3>
                <p className="text-slate-600 mb-8 leading-relaxed">
                  {industry.desc}
                </p>
                <ul className="space-y-3">
                  {industry.features.map(feat => (
                    <li key={feat} className="flex items-center gap-3 text-slate-700 font-medium">
                      <CheckCircle className="text-blue-500 shrink-0" size={18} />
                      {feat}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Quote */}
      <section className="py-24 bg-slate-900 text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <div className="grid grid-cols-6 h-full w-full">
            {Array.from({ length: 24 }).map((_, i) => (
              <div key={i} className="border-r border-b border-white/20" />
            ))}
          </div>
        </div>
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <blockquote className="max-w-4xl mx-auto">
            <p className="text-2xl md:text-4xl font-medium text-blue-100 leading-relaxed mb-8">
              "Riveting Data Consult Limited is positioned as a bridge between high-level technology and the practical needs of the African business ecosystem."
            </p>
            <footer className="text-white font-bold tracking-widest uppercase">
              Corporate Vision Statement
            </footer>
          </blockquote>
        </div>
      </section>
    </div>
  );
}