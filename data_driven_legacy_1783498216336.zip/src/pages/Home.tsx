import React from 'react';
import { motion } from 'framer-motion';
import { 
  BarChart3, 
  Code2, 
  Bot, 
  Settings2, 
  GraduationCap, 
  ShieldCheck, 
  ArrowRight,
  CheckCircle2,
  Zap
} from 'lucide-react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  const services = [
    {
      Icon: Code2,
      title: "Software & Web Development",
      description: "Custom digital solutions tailored to your business needs, from MVPs to enterprise platforms."
    },
    {
      Icon: BarChart3,
      title: "Data Analytics",
      description: "Turn your business data into actionable insights with our advanced visualization and analysis tools."
    },
    {
      Icon: Bot,
      title: "AI Agents & Chatbots",
      description: "Automate customer support and internal workflows with intelligent AI-powered assistants."
    },
    {
      Icon: Settings2,
      title: "Process Automation",
      description: "Streamline operations and eliminate repetitive tasks with our custom automation workflows."
    },
    {
      Icon: GraduationCap,
      title: "Microsoft Tech Trainings",
      description: "Official Microsoft technology certifications and practical digital skills for your workforce."
    },
    {
      Icon: ShieldCheck,
      title: "Regulatory Compliance",
      description: "Navigate business registration and legal requirements with expert guidance and support."
    }
  ];

  const features = [
    { title: "Data-Driven", description: "Decisions backed by rigorous analysis and empirical evidence." },
    { title: "Practical Impact", description: "Real-world solutions that translate into immediate business growth." },
    { title: "Local Context", description: "Deep understanding of the Nigerian and African business ecosystem." },
    { title: "Global Standards", description: "Delivering excellence that competes on an international scale." }
  ];

  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full -z-10 bg-gradient-to-br from-blue-50 to-white opacity-70"></div>
        <div 
          className="absolute top-0 right-0 w-1/2 h-full -z-10 bg-blue-600/5 hidden lg:block"
          style={{ clipPath: 'polygon(20% 0%, 100% 0%, 100% 100%, 0% 100%)' }}
        ></div>
        
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="lg:w-1/2 space-y-8"
            >
              <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-700 px-4 py-1.5 rounded-full text-sm font-semibold">
                <Zap className="w-4 h-4" />
                <span>Empowering Business through Innovation</span>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-slate-900 leading-tight">
                Driving Growth with <span className="text-blue-600">Technology & Data</span> Solutions
              </h1>
              <p className="text-lg md:text-xl text-slate-600 leading-relaxed max-w-2xl">
                Riveting Data Consult Limited helps startups, SMEs, and government programs scale through digital transformation, automation, and capacity building.
              </p>
              <div className="flex flex-wrap gap-4 pt-4">
                <Link to="/contact" className="bg-blue-600 text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-blue-700 transition-all shadow-xl shadow-blue-200">
                  Talk to Our Team
                </Link>
                <Link to="/services" className="bg-white text-slate-900 border border-slate-200 px-8 py-4 rounded-lg font-bold text-lg hover:bg-slate-50 transition-all">
                  Explore Services
                </Link>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="lg:w-1/2 relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img 
                  src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/corporate-meeting-5df1bdb2-1775109604754.webp" 
                  alt="Corporate Consulting" 
                  className="w-full aspect-[4/3] object-cover"
                />
                <div className="absolute inset-0 bg-blue-900/10"></div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-blue-600 font-bold uppercase tracking-wider text-sm mb-4">What We Offer</h2>
            <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">Comprehensive Digital & Business Solutions</h3>
            <p className="text-slate-600 text-lg">We provide end-to-end consulting and technology services designed to optimize your business operations and accelerate impact.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="group p-8 rounded-2xl bg-slate-50 border border-slate-100 hover:bg-blue-600 transition-all duration-300 shadow-sm hover:shadow-xl"
              >
                <div className="mb-6 group-hover:scale-110 transition-transform duration-300">
                  <div className="w-16 h-16 bg-white rounded-xl shadow-sm flex items-center justify-center group-hover:bg-blue-500">
                    <service.Icon className="w-8 h-8 text-blue-600 group-hover:text-white" />
                  </div>
                </div>
                <h4 className="text-xl font-bold text-slate-900 mb-4 group-hover:text-white transition-colors">{service.title}</h4>
                <p className="text-slate-600 group-hover:text-blue-50 leading-relaxed transition-colors">{service.description}</p>
              </motion.div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <Link to="/services" className="inline-flex items-center text-blue-600 font-bold hover:text-blue-700">
              View All Services <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-slate-900 text-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <img 
            src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/data-and-tech-solutions-3fd31f0b-1775109604218.webp" 
            className="w-full h-full object-cover" 
            alt="Data Background"
          />
        </div>
        <div className="container mx-auto px-4 md:px-6 lg:px-8 relative z-10">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            <div className="lg:w-1/2">
              <h2 className="text-blue-400 font-bold uppercase tracking-wider text-sm mb-4">Our Advantage</h2>
              <h3 className="text-3xl md:text-4xl font-bold mb-8">Why Riveting Data Consult?</h3>
              <p className="text-slate-400 text-lg mb-10 leading-relaxed">
                We combine deep technical expertise with business strategy to deliver solutions that are not just modern, but sustainable and effective in the local market.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                {features.map((feature, idx) => (
                  <div key={idx} className="flex gap-4">
                    <CheckCircle2 className="w-6 h-6 text-blue-400 flex-shrink-0" />
                    <div>
                      <h4 className="font-bold mb-2">{feature.title}</h4>
                      <p className="text-slate-400 text-sm leading-relaxed">{feature.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="lg:w-1/2">
              <div className="bg-slate-800/50 backdrop-blur-sm p-10 rounded-3xl border border-slate-700">
                <h4 className="text-2xl font-bold mb-6">Request a Strategic Consultation</h4>
                <p className="text-slate-400 mb-8">Ready to transform your business? Let's discuss your goals and how our technology solutions can get you there.</p>
                <form className="space-y-4">
                  <input type="text" placeholder="Full Name" className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500" />
                  <input type="email" placeholder="Email Address" className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500" />
                  <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition-all" type="button">
                    Book Discovery Call
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Academy Section Preview */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="bg-blue-600 rounded-3xl overflow-hidden shadow-2xl flex flex-col lg:flex-row">
            <div className="lg:w-1/2 p-12 lg:p-16 text-white space-y-8">
              <div className="bg-blue-500 w-fit px-4 py-1 rounded-full text-sm font-bold">Featured Program</div>
              <h2 className="text-3xl md:text-4xl font-bold">Riveting Digital Academy</h2>
              <p className="text-blue-100 text-lg leading-relaxed">
                Upskilling the next generation of digital leaders. From Microsoft technology certifications to EdTech solutions, we bridge the skill gap for youth and professionals.
              </p>
              <ul className="space-y-4">
                {['Microsoft Technologies', 'Digital Literacy', 'Workforce Development', 'EdTech Solutions'].map((item) => (
                  <li key={item} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-white"></div>
                    </div>
                    <span className="font-medium">{item}</span>
                  </li>
                ))}
              </ul>
              <Link to="/academy" className="inline-block bg-white text-blue-600 px-8 py-4 rounded-lg font-bold text-lg hover:bg-blue-50 transition-all">
                Learn More
              </Link>
            </div>
            <div className="lg:w-1/2 relative min-h-[400px]">
              <img 
                src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/digital-academy-training-005567b5-1775109604593.webp" 
                alt="Digital Academy" 
                className="absolute inset-0 w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;