import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Mail, 
  Phone, 
  MessageCircle, 
  MapPin, 
  Send,
  Loader2,
  Share2
} from 'lucide-react';
import { toast } from 'sonner';

export default function Contact() {
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      toast.success('Message sent successfully! We will get back to you soon.');
      (e.target as HTMLFormElement).reset();
    }, 1500);
  };

  return (
    <div className="pt-20">
      <section className="py-24 bg-slate-50 border-b border-slate-200">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">Let's Build Something Great</h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              Whether you're a startup looking for strategy or a government program needing tech implementation, our team is ready to help.
            </p>
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <div className="bg-white p-8 md:p-12 rounded-[2rem] border border-slate-100 shadow-xl shadow-blue-500/5">
              <h2 className="text-3xl font-bold text-slate-900 mb-8">Send us a message</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Full Name</label>
                    <input 
                      required
                      type="text" 
                      placeholder="e.g. Chinedu Okafor"
                      className="w-full px-5 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Email Address</label>
                    <input 
                      required
                      type="email" 
                      placeholder="e.g. name@company.com"
                      className="w-full px-5 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Service Interest</label>
                  <select className="w-full px-5 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all appearance-none">
                    <option>Business Consulting</option>
                    <option>Digital Academy / Training</option>
                    <option>Software Development</option>
                    <option>Data & AI Solutions</option>
                    <option>Process Automation</option>
                    <option>Registration & Compliance</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Message</label>
                  <textarea 
                    required
                    rows={5}
                    placeholder="Tell us about your project or inquiry..."
                    className="w-full px-5 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all resize-none"
                  ></textarea>
                </div>
                <button 
                  disabled={loading}
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-xl shadow-blue-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {loading ? <Loader2 className="animate-spin" /> : <><Send size={20} /> Send Message</>}
                </button>
              </form>
            </div>

            {/* Contact Info */}
            <div className="flex flex-col justify-center">
              <div className="space-y-12">
                <div>
                  <h3 className="text-blue-600 font-bold tracking-widest uppercase text-sm mb-6">Contact Information</h3>
                  <div className="space-y-6">
                    <a href="mailto:cchukwuwike@riveting-group.com.ng" className="flex items-center gap-6 group">
                      <div className="bg-blue-50 w-14 h-14 rounded-2xl flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                        <Mail size={24} />
                      </div>
                      <div>
                        <div className="text-slate-500 text-sm font-medium">Email Us</div>
                        <div className="text-lg font-bold text-slate-900">cchukwuwike@riveting-group.com.ng</div>
                      </div>
                    </a>
                    <a href="tel:+2347068871897" className="flex items-center gap-6 group">
                      <div className="bg-blue-50 w-14 h-14 rounded-2xl flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                        <Phone size={24} />
                      </div>
                      <div>
                        <div className="text-slate-500 text-sm font-medium">Call Us</div>
                        <div className="text-lg font-bold text-slate-900">+234 706 887 1897</div>
                      </div>
                    </a>
                    <div className="flex items-center gap-6 group">
                      <div className="bg-blue-50 w-14 h-14 rounded-2xl flex items-center justify-center text-blue-600">
                        <MapPin size={24} />
                      </div>
                      <div>
                        <div className="text-slate-500 text-sm font-medium">Location</div>
                        <div className="text-lg font-bold text-slate-900">Lagos, Nigeria</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-blue-600 font-bold tracking-widest uppercase text-sm mb-6">Connect With Us</h3>
                  <div className="flex gap-4">
                    <a 
                      href="https://wa.me/2347068871897" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-2xl shadow-lg transition-all flex items-center gap-3 font-bold"
                    >
                      <MessageCircle size={24} />
                      WhatsApp
                    </a>
                    <a 
                      href="https://ng.linkedin.com/company/riveting-data-consult-rdc" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-blue-700 hover:bg-blue-800 text-white p-4 rounded-2xl shadow-lg transition-all flex items-center gap-3 font-bold"
                    >
                      <Share2 size={24} />
                      LinkedIn
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}