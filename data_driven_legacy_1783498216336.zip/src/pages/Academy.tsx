import React from 'react';
import { motion } from 'framer-motion';
import { 
  Terminal, 
  Briefcase, 
  Lightbulb, 
  Users2, 
  Rocket,
  CheckCircle,
  Laptop,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';

const programs = [
  {
    title: 'Microsoft Technology Stack',
    desc: 'Professional training in Power BI, Azure Fundamentals, and M365 collaboration tools.',
    tags: ['Data', 'Cloud', 'Productivity']
  },
  {
    title: 'Digital Literacy for SMEs',
    desc: 'Empowering small business owners with essential digital tools for operations and marketing.',
    tags: ['Business', 'SME', 'Growth']
  },
  {
    title: 'Full-Stack Web Development',
    desc: 'A comprehensive journey from frontend basics to backend mastery with modern frameworks.',
    tags: ['Coding', 'Career', 'Tech']
  },
  {
    title: 'AI & Machine Learning Basics',
    desc: 'Understanding the fundamentals of AI and how to leverage LLMs for business productivity.',
    tags: ['AI', 'Future', 'Innovation']
  }
];

export default function Academy() {
  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/academy---learning-environment-4e71dd54-1775109653903.webp" 
            alt="Academy Learning"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-blue-900/80 backdrop-blur-sm" />
        </div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-white">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-3xl"
          >
            <div className="inline-block px-4 py-1 bg-white/10 rounded-full border border-white/20 text-white font-bold text-sm mb-6">
              RIVETING DIGITAL ACADEMY
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Empowering the <span className="text-blue-400">Next Generation</span> of Digital Talent</h1>
            <p className="text-xl text-blue-50/80 leading-relaxed mb-8">
              Bridge the gap between education and employment. Our academy provides practical, industry-aligned training to help you thrive in the digital economy.
            </p>
            <div className="flex flex-wrap gap-4">
              <a href="#programs" className="bg-white text-blue-900 px-8 py-4 rounded-xl font-bold text-lg hover:bg-slate-100 transition-all shadow-xl shadow-white/5">
                Explore Programs
              </a>
              <Link to="/contact" className="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-all border border-blue-500">
                Inquire for Corporate Training
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Philosophy */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-blue-600 font-bold tracking-widest uppercase text-sm mb-4">Our Educational Path</h2>
              <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-8 leading-tight">From Skills to Employment & Entrepreneurship</h3>
              
              <div className="space-y-8">
                {[
                  {
                    icon: Lightbulb,
                    title: 'Practical Curriculum',
                    desc: 'We focus on skills that are actually in demand in the modern workplace, moving beyond theory to application.'
                  },
                  {
                    icon: Users2,
                    title: 'Mentorship Led',
                    desc: 'Learn from industry professionals who have real-world experience in the tech and consulting space.'
                  },
                  {
                    icon: Rocket,
                    title: 'Career Outcomes',
                    desc: "Our goal isn't just teaching; it's helping you land a job, start a business, or secure a promotion."
                  }
                ].map((item, idx) => (
                  <div key={idx} className="flex gap-6">
                    <div className="bg-blue-50 w-12 h-12 rounded-xl flex items-center justify-center shrink-0">
                      <item.icon className="text-blue-600 w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-900 mb-2">{item.title}</h4>
                      <p className="text-slate-600 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-slate-50 p-8 md:p-12 rounded-[2.5rem] border border-slate-200">
              <div className="aspect-video rounded-2xl bg-slate-200 mb-8 overflow-hidden">
                 <img src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/service---data-analytics-ac87bce4-1775109660240.webp" alt="Training" className="w-full h-full object-cover" />
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-sm">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">JD</div>
                  <div>
                    <div className="font-bold text-slate-900">John Doe</div>
                    <div className="text-sm text-slate-500">Academy Alumni</div>
                  </div>
                </div>
                <p className="text-slate-600 italic">
                  "The Microsoft Power BI training at Riveting Academy was a game-changer for my career. I was able to automate all our quarterly reports within a month of completing the program."
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Programs List */}
      <section id="programs" className="py-24 bg-slate-900 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-blue-400 font-bold tracking-widest uppercase text-sm mb-3">Training Paths</h2>
            <h3 className="text-3xl md:text-4xl font-bold">Featured Programs</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {programs.map((prog, idx) => (
              <div key={idx} className="bg-slate-800 p-8 rounded-2xl border border-slate-700 hover:border-blue-500 transition-all">
                <div className="flex gap-2 mb-4">
                  {prog.tags.map(tag => (
                    <span key={tag} className="text-[10px] font-bold px-2 py-0.5 bg-blue-600/20 text-blue-400 border border-blue-500/20 rounded-md">
                      {tag}
                    </span>
                  ))}
                </div>
                <h4 className="text-xl font-bold mb-4">{prog.title}</h4>
                <p className="text-slate-400 text-sm mb-6 leading-relaxed">{prog.desc}</p>
                <Link to="/contact" className="text-blue-400 font-bold flex items-center gap-2 group hover:text-white transition-colors">
                  Learn More <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}