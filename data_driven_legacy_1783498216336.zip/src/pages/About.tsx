import React from 'react';
import { motion } from 'framer-motion';
import { Target, Eye, Rocket, Award, Lightbulb, Users2 } from 'lucide-react';

const About: React.FC = () => {
  const values = [
    {
      icon: <Target className="w-10 h-10 text-blue-600" />,
      title: "Data-Driven Approach",
      description: "We believe in the power of data to inform strategy and drive measurable results."
    },
    {
      icon: <Rocket className="w-10 h-10 text-blue-600" />,
      title: "Impact Focused",
      description: "Our solutions are designed to create lasting positive change for businesses and communities."
    },
    {
      icon: <Lightbulb className="w-10 h-10 text-blue-600" />,
      title: "Innovation First",
      description: "Continuously exploring new technologies to give our clients a competitive edge."
    }
  ];

  return (
    <div className="pt-24">
      {/* Hero */}
      <section className="bg-slate-50 py-20">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6">Empowering Digital Transformation</h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              Riveting Data Consult Limited is a forward-thinking business consulting and digital solutions company dedicated to the growth of startups, SMEs, and government programs.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="bg-blue-50 p-10 rounded-3xl border border-blue-100">
                <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-blue-200">
                  <Eye className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-slate-900 mb-4">Our Vision</h2>
                <p className="text-slate-600 leading-relaxed">
                  To be Africa's leading catalyst for digital excellence and business transformation, bridging the gap between technology and sustainable impact.
                </p>
              </div>
              <div className="bg-slate-900 p-10 rounded-3xl text-white">
                <div className="w-16 h-16 bg-blue-500 rounded-2xl flex items-center justify-center mb-6">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
                <p className="text-slate-300 leading-relaxed">
                  To provide practical technology, data, and capacity-building solutions that empower entrepreneurs, institutions, and governments to thrive in a digital economy.
                </p>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/strategy-and-branding-bfdd7644-1775109604686.webp" 
                alt="Strategy Session" 
                className="rounded-3xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-8 rounded-2xl shadow-xl hidden lg:block border border-slate-100 max-w-xs">
                <p className="text-blue-600 font-bold mb-2 italic">"Innovation is at the heart of everything we do."</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-slate-200 rounded-full overflow-hidden">
                    <div className="w-full h-full bg-blue-100 flex items-center justify-center">
                       <Users2 className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-bold">C. Chukwuwike</div>
                    <div className="text-xs text-slate-500">Managing Director</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">The Riveting Way</h2>
            <p className="text-slate-600 text-lg">Our core values guide every interaction and project we undertake.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {values.map((value, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100 text-center"
              >
                <div className="mx-auto w-20 h-20 bg-blue-50 rounded-2xl flex items-center justify-center mb-8">
                  {value.icon}
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-4">{value.title}</h3>
                <p className="text-slate-600 leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Experience / Impact */}
      <section className="py-24">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            <div className="lg:w-1/2">
               <h2 className="text-blue-600 font-bold uppercase tracking-wider text-sm mb-4">Our Experience</h2>
               <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-8">Trusted by Entrepreneurs & Institutions</h3>
               <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                 With years of experience in the entrepreneurship ecosystem, we have worked closely with Microsoft programs and EdTech initiatives to deliver high-impact solutions.
               </p>
               <div className="space-y-4">
                 {[
                   'Deep expertise in Microsoft Ecosystem',
                   'Proven track record with NGOs & Gov programs',
                   'Specialized EdTech development & deployment',
                   'Comprehensive business strategy for startups'
                 ].map((item, idx) => (
                   <div key={idx} className="flex items-center gap-3">
                     <Award className="w-5 h-5 text-blue-600" />
                     <span className="font-semibold text-slate-700">{item}</span>
                   </div>
                 ))}
               </div>
            </div>
            <div className="lg:w-1/2 grid grid-cols-2 gap-4">
               <div className="space-y-4">
                  <div className="bg-blue-600 p-8 rounded-3xl text-white text-center">
                    <div className="text-4xl font-bold mb-2">10+</div>
                    <div className="text-sm font-medium">Core Services</div>
                  </div>
                  <div className="bg-slate-100 p-8 rounded-3xl text-center">
                    <div className="text-4xl font-bold text-blue-600 mb-2">24/7</div>
                    <div className="text-sm font-medium text-slate-600">Support Available</div>
                  </div>
               </div>
               <div className="pt-8 space-y-4">
                  <div className="bg-slate-900 p-8 rounded-3xl text-white text-center">
                    <div className="text-4xl font-bold mb-2">100%</div>
                    <div className="text-sm font-medium">Data Driven</div>
                  </div>
                  <div className="bg-blue-50 p-8 rounded-3xl text-center">
                    <div className="text-4xl font-bold text-blue-600 mb-2">SME</div>
                    <div className="text-sm font-medium text-slate-600">Specialists</div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;