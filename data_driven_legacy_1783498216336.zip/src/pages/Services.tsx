import React from 'react';
import { motion } from 'framer-motion';
import { 
  Palette, 
  Code2, 
  BarChart3, 
  MessageSquareCode, 
  Cpu, 
  GraduationCap, 
  FileText, 
  Scale, 
  ArrowRight,
  MonitorSmartphone,
  PieChart,
  Bot
} from 'lucide-react';
import { Link } from 'react-router-dom';

const Services: React.FC = () => {
  const serviceCategories = [
    {
      title: "Strategy & Branding",
      icon: <Palette className="w-10 h-10" />,
      items: [
        { name: "Business Branding", description: "Creating visual identities that resonate with your target market." },
        { name: "Brand Strategy", description: "Strategic positioning and market entry plans for startups." },
        { name: "Marketing Strategy", description: "Data-driven marketing funnels to drive conversion." }
      ]
    },
    {
      title: "Digital Solutions",
      icon: <MonitorSmartphone className="w-10 h-10" />,
      items: [
        { name: "Web Development", description: "Custom, responsive, and SEO-optimized web applications." },
        { name: "Software Development", description: "Bespoke software solutions to solve specific business problems." },
        { name: "Mobile App Design", description: "User-centric mobile experiences for iOS and Android." }
      ]
    },
    {
      title: "Data & Automation",
      icon: <Cpu className="w-10 h-10" />,
      items: [
        { name: "AI Agents & Chatbots", description: "Intelligent automation for customer service and operations." },
        { name: "Process Automation", description: "Workflow optimizations using modern automation tools." },
        { name: "Data Analytics", description: "Advanced visualization and insights from your raw data." }
      ]
    },
    {
      title: "Training & Support",
      icon: <GraduationCap className="w-10 h-10" />,
      items: [
        { name: "Microsoft Training", description: "Specialized training on MS Office, Azure, and Dynamics." },
        { name: "Digital Skill Workshops", description: "Capacity building for youth and workforce programs." },
        { name: "Compliance Support", description: "Business registration, legal filings, and regulatory advisory." }
      ]
    }
  ];

  return (
    <div className="pt-24">
      {/* Header */}
      <section className="bg-slate-900 py-24 text-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-extrabold mb-6">Our Services</h1>
            <p className="text-xl text-slate-400 leading-relaxed">
              We provide a holistic approach to business growth by combining creative strategy with cutting-edge technology and data intelligence.
            </p>
          </div>
        </div>
      </section>

      {/* Detailed Services Grid */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="space-y-24">
            {serviceCategories.map((category, catIdx) => (
              <div key={catIdx} className="scroll-mt-32">
                <div className="flex items-center gap-4 mb-12">
                  <div className="bg-blue-600 p-4 rounded-2xl text-white shadow-lg shadow-blue-200">
                    {category.icon}
                  </div>
                  <h2 className="text-3xl font-bold text-slate-900">{category.title}</h2>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {category.items.map((item, itemIdx) => (
                    <motion.div 
                      key={itemIdx}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: itemIdx * 0.1 }}
                      viewport={{ once: true }}
                      className="group p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:bg-white hover:shadow-xl transition-all border-l-4 hover:border-l-blue-600"
                    >
                      <h3 className="text-xl font-bold text-slate-900 mb-4 group-hover:text-blue-600 transition-colors">{item.name}</h3>
                      <p className="text-slate-600 leading-relaxed mb-6">{item.description}</p>
                      <div className="h-1 w-12 bg-blue-200 group-hover:w-full transition-all duration-500"></div>
                    </motion.div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-24 bg-blue-600 text-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="bg-blue-700 p-12 lg:p-20 rounded-[3rem] text-center max-w-5xl mx-auto border border-blue-500 shadow-2xl">
            <h2 className="text-3xl md:text-5xl font-bold mb-8 italic">Ready to transform your business operations?</h2>
            <p className="text-xl text-blue-100 mb-12 max-w-3xl mx-auto leading-relaxed">
              Whether you're a startup looking for an MVP or a government body needing digital transformation, we have the expertise to deliver.
            </p>
            <div className="flex flex-wrap justify-center gap-6">
              <Link to="/contact" className="bg-white text-blue-600 px-10 py-4 rounded-full font-bold text-lg hover:bg-blue-50 transition-all flex items-center gap-2">
                Request a Proposal <ArrowRight className="w-5 h-5" />
              </Link>
              <a href="https://wa.me/2347068871897" className="bg-blue-500 text-white border border-blue-400 px-10 py-4 rounded-full font-bold text-lg hover:bg-blue-400 transition-all">
                WhatsApp Us
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;