import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, ArrowRight, Globe } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  const logoUrl = "https://storage.googleapis.com/dala-prod-public-storage/attachments/468e8d18-7b75-4c1e-9971-d2e7bc2ceab5/1775162090522_Riveting_Data_Consult_Updated_Logo.png";

  return (
    <footer className="bg-slate-950 text-slate-300 pt-20 pb-10">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <Link to="/" className="inline-block">
              <img 
                src={logoUrl} 
                alt="Riveting Data Consult Logo" 
                className="h-12 w-auto brightness-0 invert opacity-90 hover:opacity-100 transition-opacity"
              />
            </Link>
            <p className="text-slate-400 leading-relaxed max-w-xs">
              Empowering startups, SMEs, and government institutions through data-driven strategies, 
              cutting-edge technology, and practical digital skills training.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://ng.linkedin.com/company/riveting-data-consult-rdc" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-blue-600 transition-colors"
              >
                <Globe size={20} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-bold text-lg mb-6">Services</h3>
            <ul className="space-y-4">
              {[
                'Business Branding & Strategy',
                'Software & Website Development',
                'Data Analytics & Digital Marketing',
                'AI Agents & Chatbots',
                'Business Process Automations',
                'Microsoft Technology Trainings',
              ].map((service) => (
                <li key={service}>
                  <Link to="/services" className="hover:text-blue-400 flex items-center group font-medium text-sm transition-all">
                    <ArrowRight size={14} className="mr-2 opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all text-blue-400" />
                    {service}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold text-lg mb-6">Quick Links</h3>
            <ul className="space-y-4">
              {[
                { name: 'About Us', path: '/about' },
                { name: 'Digital Academy', path: '/academy' },
                { name: 'Industries We Serve', path: '/industries' },
                { name: 'Contact Us', path: '/contact' },
                { name: 'Privacy Policy', path: '#' },
              ].map((link) => (
                <li key={link.name}>
                  <Link to={link.path} className="hover:text-blue-400 font-medium text-sm transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold text-lg mb-6">Contact Info</h3>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <Mail size={20} className="text-blue-500 mt-1 shrink-0" />
                <a href="mailto:cchukwuwike@riveting-group.com.ng" className="hover:text-blue-400 break-all text-sm font-medium">
                  cchukwuwike@riveting-group.com.ng
                </a>
              </li>
              <li className="flex items-start space-x-3">
                <Phone size={20} className="text-blue-500 mt-1 shrink-0" />
                <a href="tel:+2347068871897" className="hover:text-blue-400 text-sm font-medium">
                  +234 706 887 1897
                </a>
              </li>
              <li className="flex items-start space-x-3 text-slate-400">
                <MapPin size={20} className="text-blue-500 mt-1 shrink-0" />
                <span className="text-sm font-medium">Lagos, Nigeria</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-slate-500 font-medium">
          <p>© {currentYear} Riveting Data Consult Limited. All rights reserved.</p>
          <p className="mt-2 md:mt-0 italic text-blue-500/80">Driving Impact Through Data & Technology</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;