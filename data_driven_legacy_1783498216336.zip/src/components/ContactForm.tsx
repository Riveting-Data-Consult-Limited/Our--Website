import { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Phone, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';

export function ContactForm() {
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      toast.success('Message sent! We will contact you shortly.', {
        description: 'Thank you for reaching out to Riveting Data Consult.',
      });
      setLoading(false);
      (e.target as HTMLFormElement).reset();
    }, 1500);
  };

  return (
    <div className="bg-white rounded-3xl shadow-2xl shadow-blue-500/5 border border-slate-100 p-8 md:p-12 overflow-hidden relative">
      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-full -translate-y-1/2 translate-x-1/2 -z-1" />
      
      <div className="relative z-10">
        <h3 className="text-2xl font-bold text-slate-900 mb-2">Send us a message</h3>
        <p className="text-slate-500 text-sm mb-8">We respond within 24 hours on business days.</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Full Name</label>
              <input
                required
                type="text"
                placeholder="John Doe"
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Email Address</label>
              <input
                required
                type="email"
                placeholder="john@company.com"
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Subject</label>
            <select
              required
              className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
            >
              <option value="">Select a service</option>
              <option value="consulting">Business Consulting</option>
              <option value="tech">Software Development</option>
              <option value="academy">Digital Academy</option>
              <option value="automation">Process Automation</option>
              <option value="other">Other Inquiry</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Message</label>
            <textarea
              required
              rows={4}
              placeholder="Tell us about your project or needs..."
              className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all resize-none"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 flex items-center justify-center space-x-2 disabled:opacity-70"
          >
            {loading ? (
              <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <span>Send Message</span>
                <Send size={18} />
              </>
            )}
          </button>
        </form>

        <div className="mt-10 pt-8 border-t border-slate-100 grid grid-cols-2 gap-4">
          <a
            href="https://wa.me/2347068871897"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center space-x-2 py-3 bg-emerald-50 text-emerald-700 rounded-lg text-sm font-bold hover:bg-emerald-100 transition-colors"
          >
            <MessageSquare size={16} />
            <span>WhatsApp</span>
          </a>
          <a
            href="tel:+2347068871897"
            className="flex items-center justify-center space-x-2 py-3 bg-blue-50 text-blue-700 rounded-lg text-sm font-bold hover:bg-blue-100 transition-colors"
          >
            <Phone size={16} />
            <span>Call Us</span>
          </a>
        </div>
      </div>
    </div>
  );
}