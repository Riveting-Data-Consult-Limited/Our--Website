import React from 'react';
import { motion } from 'framer-motion';
import { 
  Rocket, 
  Code2, 
  BarChart3, 
  Cpu, 
  Settings, 
  GraduationCap, 
  FileText, 
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const Services = () => {
  const serviceList = [
    {
      title: 'Business Branding & Strategy',
      icon: <Rocket />,
      description: 'We help startups and SMEs define their market position, brand identity, and long-term growth roadmap.',
      useCases: ['Market Entry Strategies', 'Brand Identity Design', 'Business Model Optimization'],
    },
    {
      title: 'Software & Website Development',
      icon: <Code2 />,
      description: 'Building modern, responsive, and high-performance digital platforms tailored to your business needs.',
      useCases: ['E-commerce Platforms', 'Corporate Websites', 'Custom Web Applications'],
    },
    {
      title: 'Data Analytics & Digital Marketing',
      icon: <BarChart3 />,
      description: 'Transforming data into growth. We use analytics to optimize your digital marketing ROI.',
      useCases: ['Customer Behavior Analysis', 'Marketing Performance Dashboards', 'Targeted Ad Campaigns'],
    },
    {
      title: 'AI Agents & Chatbots',
      icon: <Cpu />,
      description: 'Enhancing customer experience and internal efficiency through intelligent automation.',
      useCases: ['24/7 Customer Support Bots', 'Lead Generation AI', 'Internal Process Assistants'],
    },
    {
      title: 'Business Process Automations',
      icon: <Settings />,
      description: 'Eliminating manual bottlenecks by automating repetitive tasks across your organization.',
      useCases: ['Workflow Optimization', 'Document Management Systems', 'Automated Reporting'],
    },
    {
      title: 'Microsoft Technology Trainings',
      icon: <GraduationCap />,
      description: 'Empowering teams with expertise in the Microsoft ecosystem, from Office 365 to Azure.',
      useCases: ['Power Platform Training', 'Azure Cloud Fundamentals', 'Office 365 Adoption'],
    },
    {
      title: 'Business Registration & Documentation',
      icon: <FileText />,
      description: 'Handling the technicalities of CAC registration and corporate documentation so you can focus on growth.',
      useCases: ['CAC New Registration', 'Annual Filings', 'Post-incorporation Updates'],
    },
    {
      title: 'Legal & Regulatory Compliance',
      icon: <ShieldCheck />,
      description: 'Navigating the regulatory landscape to ensure your business meets all local and international standards.',
      useCases: ['Data Privacy (NDPR) Compliance', 'Regulatory Filings', 'Corporate Governance'],
    },
  ];

  return (
    <div className="pt-24">
      {/* Header */}
      <section className="bg-slate-900 text-white py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
            <p className="text-xl text-slate-300">
              Tailored solutions designed to solve real-world business challenges 
              and drive sustainable growth for organizations of all sizes.
            </p>
          </div>
        </div>
      </section>

      {/* Service Grid */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {serviceList.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="group p-8 rounded-3xl border border-slate-100 bg-slate-50 hover:bg-white hover:shadow-xl transition-all"
              >
                <div className="flex items-start space-x-6">
                  <div className="w-16 h-16 shrink-0 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-200 group-hover:scale-110 transition-transform">
                    {React.cloneElement(service.icon as React.ReactElement<{ size?: number }>, { size: 32 })}
                  </div>
                  <div className="flex-1">
                    <h2 className="text-2xl font-bold text-slate-900 mb-4">{service.title}</h2>
                    <p className="text-slate-600 mb-6 leading-relaxed">{service.description}</p>
                    
                    <div className="space-y-3">
                      <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Use Cases:</h3>
                      <ul className="grid grid-cols-1 gap-2">
                        {service.useCases.map((useCase, i) => (
                          <li key={i} className="flex items-center text-slate-600 text-sm">
                            <CheckCircle2 size={16} className="text-blue-500 mr-2 shrink-0" />
                            {useCase}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-blue-50 border-y border-blue-100 text-center">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">Not sure what you need?</h2>
          <p className="text-slate-600 max-w-2xl mx-auto mb-10 text-lg">
            Schedule a discovery call with our consultants. We&apos;ll analyze your current state 
            and recommend the best digital path forward.
          </p>
          <Link to="/contact">
            <Button size="lg" className="h-auto py-3.5">Book a Free Discovery Call</Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Services;