import React from 'react';
import { motion } from 'framer-motion';
import { Target, Users, Lightbulb, TrendingUp } from 'lucide-react';

const About = () => {
  return (
    <div className="pt-24">
      {/* Page Header */}
      <section className="bg-slate-50 py-20 border-b border-slate-200">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">About Riveting Data Consult</h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              We are a Nigerian technology and business consulting firm dedicated to helping startups, SMEs, 
              and government institutions grow through data, automation, and capacity building.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-6 p-10 rounded-3xl bg-blue-50 border border-blue-100">
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-white mb-4">
                <Target size={28} />
              </div>
              <h2 className="text-3xl font-bold text-slate-900">Our Mission</h2>
              <p className="text-lg text-slate-700 leading-relaxed">
                To empower organizations and individuals with the digital tools, strategic insights, 
                and technical skills required to thrive in a data-driven global economy.
              </p>
            </div>
            <div className="space-y-6 p-10 rounded-3xl bg-slate-900 text-white">
              <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center text-white mb-4">
                <Lightbulb size={28} />
              </div>
              <h2 className="text-3xl font-bold text-white">Our Vision</h2>
              <p className="text-lg text-slate-300 leading-relaxed">
                To be Africa&apos;s leading partner in digital transformation, recognized for 
                driving sustainable economic impact through technology and human capital development.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Approach */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Our Approach</h2>
            <p className="text-slate-600 italic font-medium">&quot;Data-driven, Practical, Impact-focused&quot;</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {[
              {
                title: 'Consulting',
                desc: 'Deep-dive analysis of business processes and market positioning.',
                icon: <Users className="mx-auto text-blue-600" size={40} />
              },
              {
                title: 'Technology',
                desc: 'Deploying modern software and automation tools to solve real problems.',
                icon: <TrendingUp className="mx-auto text-blue-600" size={40} />
              },
              {
                title: 'Capacity Building',
                desc: 'Ensuring your workforce has the skills to manage and grow digital assets.',
                icon: <Target className="mx-auto text-blue-600" size={40} />
              },
            ].map((item, idx) => (
              <div key={idx} className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
                <div className="mb-6">{item.icon}</div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{item.title}</h3>
                <p className="text-slate-600 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2">
              <img 
                src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/business-strategy-601e75a9-1775109994310.webp" 
                alt="Our Experience" 
                className="rounded-3xl shadow-xl"
              />
            </div>
            <div className="lg:w-1/2 space-y-6">
              <h2 className="text-3xl font-bold text-slate-900">Proven Expertise in the Ecosystem</h2>
              <p className="text-lg text-slate-600 leading-relaxed">
                With a strong background in Microsoft programs and the EdTech landscape, we have consistently 
                contributed to the Nigerian entrepreneurship ecosystem. 
              </p>
              <ul className="space-y-4">
                {[
                  'Microsoft Technology Ecosystem specialists',
                  'Strategic partners for entrepreneurship hubs',
                  'Workforce development program designers',
                  'EdTech solution innovators for schools',
                ].map((item, idx) => (
                  <li key={idx} className="flex items-center space-x-3 text-slate-700">
                    <div className="w-2 h-2 bg-blue-600 rounded-full" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;