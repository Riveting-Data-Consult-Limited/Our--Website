import { motion } from 'framer-motion';
import { CheckCircle2, Award, Users, Rocket } from 'lucide-react';

const Academy = () => {
  return (
    <section id="academy" className="py-24 bg-gray-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:flex items-center gap-16">
          {/* Content */}
          <div className="lg:w-1/2 mb-12 lg:mb-0">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="text-blue-600 font-bold tracking-wider uppercase text-sm mb-3 block">Education & Skills</span>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Riveting Digital Academy
              </h2>
              <p className="text-gray-600 text-lg mb-8 leading-relaxed">
                Empowering the next generation of African professionals through world-class digital skills and Microsoft technology training. We bridge the gap between education and employment.
              </p>

              <div className="space-y-6 mb-10">
                <div className="flex items-start">
                  <div className="mt-1 bg-blue-100 p-1 rounded-full text-blue-600 mr-4">
                    <CheckCircle2 size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Microsoft Technology Training</h4>
                    <p className="text-gray-600 text-sm">Specialized tracks in Azure, Power BI, Dynamics 365, and Microsoft 365.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="mt-1 bg-blue-100 p-1 rounded-full text-blue-600 mr-4">
                    <CheckCircle2 size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">EdTech Solutions</h4>
                    <p className="text-gray-600 text-sm">Implementation of digital learning systems for schools and institutions.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="mt-1 bg-blue-100 p-1 rounded-full text-blue-600 mr-4">
                    <CheckCircle2 size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Education-to-Employment</h4>
                    <p className="text-gray-600 text-sm">Skills programs designed to meet current market demands and workforce needs.</p>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-1">500+</div>
                  <div className="text-gray-500 text-sm">Students Trained</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-1">15+</div>
                  <div className="text-gray-500 text-sm">Partnerships</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-1">90%</div>
                  <div className="text-gray-500 text-sm">Success Rate</div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Image/Visual */}
          <div className="lg:w-1/2 relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative z-10 rounded-2xl overflow-hidden shadow-2xl"
            >
              <img
                src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/digital-academy-3192bbbc-1775110361993.webp"
                alt="Digital Academy Classroom"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/60 to-transparent"></div>
              
              <div className="absolute bottom-8 left-8 right-8 bg-white/95 backdrop-blur-sm p-6 rounded-xl shadow-lg">
                <div className="flex items-center gap-4">
                  <div className="bg-blue-600 p-3 rounded-lg text-white">
                    <Award size={24} />
                  </div>
                  <div>
                    <h5 className="font-bold text-gray-900">Certified Excellence</h5>
                    <p className="text-gray-600 text-xs">Curriculum aligned with global technology standards.</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Background Decorations */}
            <div className="absolute -top-10 -right-10 w-64 h-64 bg-blue-200 rounded-full blur-3xl opacity-30 -z-0"></div>
            <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-cyan-200 rounded-full blur-3xl opacity-30 -z-0"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Academy;