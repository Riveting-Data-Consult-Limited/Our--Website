import { motion } from 'framer-motion';
import { 
  BarChart3, 
  Code2, 
  Palette, 
  Zap, 
  Cpu, 
  GraduationCap, 
  FileText, 
  Scale 
} from 'lucide-react';

const services = [
  {
    icon: <Palette className="w-8 h-8" />,
    title: 'Business Branding & Strategy',
    desc: 'Crafting unique identities and strategic roadmaps that help businesses stand out and scale.',
    color: 'bg-blue-50 text-blue-600',
  },
  {
    icon: <Code2 className="w-8 h-8" />,
    title: 'Software & Website Dev',
    desc: 'Custom digital solutions built with modern stacks to solve complex business challenges.',
    color: 'bg-cyan-50 text-cyan-600',
  },
  {
    icon: <BarChart3 className="w-8 h-8" />,
    title: 'Data Analytics & Digital Marketing',
    desc: 'Transforming raw data into actionable insights and driving growth through targeted digital campaigns.',
    color: 'bg-indigo-50 text-indigo-600',
  },
  {
    icon: <Cpu className="w-8 h-8" />,
    title: 'AI Agents & Chatbots',
    desc: 'Leveraging artificial intelligence to automate customer service and internal operations.',
    color: 'bg-purple-50 text-purple-600',
  },
  {
    icon: <Zap className="w-8 h-8" />,
    title: 'Business Process Automations',
    desc: 'Optimizing workflows with smart automation tools to increase efficiency and reduce costs.',
    color: 'bg-amber-50 text-amber-600',
  },
  {
    icon: <GraduationCap className="w-8 h-8" />,
    title: 'Microsoft Tech Trainings',
    desc: 'Official Microsoft technology training and digital literacy programs for workforces.',
    color: 'bg-green-50 text-green-600',
  },
  {
    icon: <FileText className="w-8 h-8" />,
    title: 'Business Registration',
    desc: 'Hassle-free documentation and registration services for startups and established firms.',
    color: 'bg-red-50 text-red-600',
  },
  {
    icon: <Scale className="w-8 h-8" />,
    title: 'Legal & Regulatory Support',
    desc: 'Navigating compliance and regulatory landscapes to ensure your business stays protected.',
    color: 'bg-slate-50 text-slate-600',
  },
];

const Services = () => {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-blue-600 font-bold tracking-wider uppercase text-sm mb-3"
          >
            Our Expertise
          </motion.h2>
          <motion.h3
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-4xl font-bold text-gray-900 mb-6"
          >
            Comprehensive Solutions for the Digital Age
          </motion.h3>
          <p className="text-gray-600 text-lg">
            We combine consulting, technology, and data to deliver measurable impact for our clients.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-8 rounded-2xl border border-gray-100 bg-white hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group"
            >
              <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-6 transition-colors group-hover:bg-blue-600 group-hover:text-white ${service.color}`}>
                {service.icon}
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h4>
              <p className="text-gray-600 text-sm leading-relaxed">
                {service.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;