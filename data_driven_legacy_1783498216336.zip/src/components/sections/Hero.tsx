import { motion } from 'framer-motion';
import { ArrowRight, Play } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/corporate-hq-1432efb7-1775110361985.webp"
          alt="Corporate Office"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-950/95 via-blue-900/80 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block px-4 py-1.5 mb-6 text-sm font-semibold tracking-wider text-blue-100 uppercase bg-blue-600/30 backdrop-blur-sm rounded-full border border-blue-400/30">
              Future-Proof Your Business
            </span>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6">
              Empowering Growth through <span className="text-blue-400">Data & Technology</span>
            </h1>
            <p className="text-lg md:text-xl text-blue-50/90 mb-10 leading-relaxed">
              We provide startups, SMEs, and government institutions with the digital tools, strategic consulting, and capacity building needed to thrive in the modern economy.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#contact"
                className="group flex items-center justify-center px-8 py-4 bg-blue-600 text-white rounded-lg font-bold text-lg hover:bg-blue-700 transition-all shadow-xl hover:shadow-blue-500/25"
              >
                Get a Consultation
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </a>
              <a
                href="#academy"
                className="flex items-center justify-center px-8 py-4 bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-lg font-bold text-lg hover:bg-white/20 transition-all"
              >
                <Play className="mr-2 fill-white" size={18} />
                Explore Academy
              </a>
            </div>
          </motion.div>

          {/* Trust Badges */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 1 }}
            className="mt-16 pt-8 border-t border-white/10 flex flex-wrap gap-8 items-center"
          >
            <p className="text-white/60 text-sm font-medium uppercase tracking-widest w-full mb-2 lg:w-auto lg:mb-0 lg:mr-4">
              Trusted By
            </p>
            <div className="flex gap-8 items-center grayscale opacity-70">
              <div className="text-white font-bold text-xl">Microsoft</div>
              <div className="text-white font-bold text-xl">SMEs</div>
              <div className="text-white font-bold text-xl">NGOs</div>
              <div className="text-white font-bold text-xl">Startups</div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Abstract Design Elements */}
      <div className="absolute right-0 bottom-0 w-1/3 h-full opacity-20 pointer-events-none hidden lg:block">
        <svg viewBox="0 0 400 400" className="w-full h-full text-blue-400">
          <circle cx="200" cy="200" r="150" fill="currentColor" fillOpacity="0.1" />
          <circle cx="200" cy="200" r="100" fill="currentColor" fillOpacity="0.1" />
          <circle cx="200" cy="200" r="50" fill="currentColor" fillOpacity="0.1" />
        </svg>
      </div>
    </section>
  );
};

export default Hero;