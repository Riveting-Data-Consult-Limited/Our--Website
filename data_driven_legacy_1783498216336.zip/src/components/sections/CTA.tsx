import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const CTA = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img
          src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/data-analytics-8ef10f8d-1775110361906.webp"
          alt="Data Analytics"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-blue-900/90 mix-blend-multiply"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-8 leading-tight">
            Ready to Accelerate Your Digital Transformation?
          </h2>
          <p className="text-xl text-blue-100 mb-10 leading-relaxed">
            Join hundreds of businesses and institutions that have scaled their impact with Riveting Data Consult.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <a
              href="#contact"
              className="px-10 py-4 bg-white text-blue-900 font-bold rounded-full hover:bg-blue-50 transition-all shadow-xl text-lg flex items-center justify-center group"
            >
              Get Started Now
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
            </a>
            <a
              href="https://wa.me/2347068871897"
              target="_blank"
              rel="noopener noreferrer"
              className="px-10 py-4 bg-transparent border-2 border-white/50 text-white font-bold rounded-full hover:bg-white/10 transition-all text-lg flex items-center justify-center"
            >
              Talk to an Expert
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTA;