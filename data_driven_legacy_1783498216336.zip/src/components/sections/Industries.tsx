import { motion } from 'framer-motion';
import { Building2, Lightbulb, Users2, Rocket } from 'lucide-react';

const industries = [
  {
    title: 'Startups & SMEs',
    icon: <Rocket className="w-10 h-10 text-blue-500" />,
    desc: 'Empowering early-stage ventures with scalable tech and robust business strategies to dominate their niche.',
  },
  {
    title: 'Government & NGOs',
    icon: <Building2 className="w-10 h-10 text-blue-500" />,
    desc: 'Driving public sector efficiency through data-driven governance and institutional capacity building.',
  },
  {
    title: 'Education & Skills',
    icon: <Users2 className="w-10 h-10 text-blue-500" />,
    desc: 'Transforming educational landscapes with EdTech solutions and vocational digital skills programs.',
  },
];

const Industries = () => {
  return (
    <section id="industries" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Who We Serve</h2>
          <p className="text-gray-600 text-lg">
            We specialize in creating tailored solutions for sectors with the highest potential for impact and growth.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {industries.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="text-center group p-4"
            >
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-blue-50 mb-8 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
                {index === 0 ? <Rocket className="w-10 h-10" /> : index === 1 ? <Building2 className="w-10 h-10" /> : <Users2 className="w-10 h-10" />}
              </div>
              <h4 className="text-2xl font-bold text-gray-900 mb-4">{item.title}</h4>
              <p className="text-gray-600 leading-relaxed">
                {item.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Industries;