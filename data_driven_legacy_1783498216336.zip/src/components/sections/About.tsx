import { motion } from 'framer-motion';

const About = () => {
  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:flex items-center gap-16">
          <div className="lg:w-1/2 mb-12 lg:mb-0">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img
                src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/consulting-team-850ab01c-1775110361894.webp"
                alt="Our Consulting Team"
                className="rounded-2xl shadow-2xl relative z-10"
              />
              <div className="absolute -bottom-6 -right-6 w-48 h-48 bg-blue-600/10 rounded-2xl -z-0"></div>
            </motion.div>
          </div>
          
          <div className="lg:w-1/2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-blue-600 font-bold tracking-wider uppercase text-sm mb-3">About Us</h2>
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Leading the Digital Transformation in Africa
              </h3>
              <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                Riveting Data Consult Limited is more than just a consulting firm; we are a partner in progress. We believe that technology and data are the greatest equalizers for growth in the 21st century.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <div>
                  <h4 className="font-bold text-gray-900 mb-2">Our Mission</h4>
                  <p className="text-gray-600 text-sm">To empower organizations through innovative digital solutions and strategic capacity building that drives sustainable growth.</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-2">Our Vision</h4>
                  <p className="text-gray-600 text-sm">To be Africa's leading hub for digital excellence, where technology meets human potential to create lasting impact.</p>
                </div>
              </div>

              <div className="p-6 bg-blue-50 rounded-xl border-l-4 border-blue-600">
                <p className="text-blue-900 font-medium italic">
                  "Our approach is data-driven, practical, and impact-oriented. We don't just deliver services; we build ecosystems for success."
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;