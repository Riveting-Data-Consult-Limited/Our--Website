import React from 'react';
import { motion } from 'framer-motion';
import { 
  Cloud,
  Smartphone,
  Monitor,
  Briefcase,
  CheckCircle2
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const Academy = () => {
  const programs = [
    {
      title: 'Microsoft Technology Training',
      desc: 'Expert-led workshops on Power BI, Azure, Power Automate, and Office 365.',
      icon: <Cloud className="text-blue-600" />
    },
    {
      title: 'Digital Skills for Youth',
      desc: 'Foundation courses in web development, digital marketing, and data literacy.',
      icon: <Smartphone className="text-blue-600" />
    },
    {
      title: 'EdTech Solutions',
      desc: 'Helping educational institutions implement digital learning management systems.',
      icon: <Monitor className="text-blue-600" />
    },
    {
      title: 'Workforce Development',
      desc: 'Customized training programs to upskill corporate employees for the digital age.',
      icon: <Briefcase className="text-blue-600" />
    }
  ];

  return (
    <div className="pt-24">
      {/* Hero */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/digital-academy-retry-a7134ef0-1775110008706.webp" 
            alt="Digital Academy Students" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-[2px]" />
        </div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center text-white">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-4xl mx-auto"
          >
            <div className="inline-block px-4 py-1 bg-blue-600 text-sm font-bold rounded-full mb-6 uppercase tracking-widest">
              Education-to-Employment
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Riveting Digital Academy</h1>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
              Equipping the next generation of African professionals with high-demand digital skills 
              and practical Microsoft technology expertise.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Programs Overview */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Our Training Pathways</h2>
            <p className="text-slate-600">We offer specialized programs designed for career growth and organizational efficiency.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {programs.map((program, idx) => (
              <div key={idx} className="p-8 rounded-2xl bg-slate-50 border border-slate-100 text-center hover:bg-blue-600 hover:text-white transition-all group">
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm group-hover:scale-110 transition-transform">
                  {React.cloneElement(program.icon as React.ReactElement<{ size?: number }>, { size: 32 })}
                </div>
                <h3 className="text-xl font-bold mb-3">{program.title}</h3>
                <p className="text-slate-600 group-hover:text-blue-50">{program.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Impact Story / Pathway */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2">
              <h2 className="text-3xl font-bold text-slate-900 mb-8">Empowering Careers</h2>
              <div className="space-y-6">
                {[
                  {
                    title: 'Practical Curriculum',
                    desc: 'Hands-on projects that mirror real-world business scenarios.'
                  },
                  {
                    title: 'Certification Ready',
                    desc: 'Preparation for global Microsoft and technology certifications.'
                  },
                  {
                    title: 'Placement Support',
                    desc: 'Connecting top graduates with our network of startups and SME partners.'
                  }
                ].map((item, i) => (
                  <div key={i} className="flex space-x-4">
                    <CheckCircle2 className="text-blue-600 shrink-0 mt-1" />
                    <div>
                      <h4 className="font-bold text-slate-900">{item.title}</h4>
                      <p className="text-slate-600">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
              <Button className="mt-10 h-auto py-3.5" size="lg">Apply for Next Cohort</Button>
            </div>
            <div className="lg:w-1/2 grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-48 bg-blue-600 rounded-3xl flex items-center justify-center text-white p-8 text-center">
                   <div>
                    <div className="text-4xl font-bold mb-1">500+</div>
                    <div className="text-sm font-medium">Students Trained</div>
                  </div>
                </div>
                <div className="h-64 bg-slate-900 rounded-3xl flex items-center justify-center text-white p-8 relative overflow-hidden text-center">
                  <img src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/business-strategy-601e75a9-1775109994310.webp" className="opacity-40 object-cover absolute inset-0 w-full h-full" alt="" />
                  <div className="relative z-10">
                    <div className="text-4xl font-bold mb-1">90%</div>
                    <div className="text-sm font-medium">Employment Rate</div>
                  </div>
                </div>
              </div>
              <div className="pt-8 space-y-4">
                <div className="h-64 bg-slate-200 rounded-3xl overflow-hidden">
                   <img 
                    src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/digital-academy-retry-a7134ef0-1775110008706.webp" 
                    alt="Training" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="h-48 bg-blue-100 rounded-3xl flex items-center justify-center text-blue-600 p-8 text-center">
                  <div>
                    <div className="text-4xl font-bold mb-1">20+</div>
                    <div className="text-sm font-medium">Corporate Partners</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Academy;