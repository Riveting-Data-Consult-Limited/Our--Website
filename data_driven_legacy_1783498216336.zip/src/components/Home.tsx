import React from 'react';
import { motion } from 'framer-motion';
import { 
  BarChart3, 
  Code2, 
  Cpu, 
  LineChart, 
  Rocket, 
  ArrowRight,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const Home = () => {
  const services = [
    {
      title: 'Business Branding & Strategy',
      description: 'Crafting unique identities and growth strategies for modern businesses.',
      icon: <Rocket className="text-blue-600" size={32} />,
    },
    {
      title: 'Software & Website Dev',
      description: 'Custom digital solutions built for scalability and performance.',
      icon: <Code2 className="text-blue-600" size={32} />,
    },
    {
      title: 'Data Analytics',
      description: 'Turning raw data into actionable insights for better decision making.',
      icon: <LineChart className="text-blue-600" size={32} />,
    },
    {
      title: 'AI Agents & Chatbots',
      description: 'Automating customer engagement with intelligent AI solutions.',
      icon: <Cpu className="text-blue-600" size={32} />,
    },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden pt-20">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/corporate-hero-28319c20-1775109994600.webp" 
            alt="Corporate Environment" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-transparent" />
        </div>

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl"
          >
            <div className="inline-flex items-center space-x-2 bg-blue-600/20 backdrop-blur-sm border border-blue-500/30 px-3 py-1 rounded-full mb-6">
              <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
              <span className="text-blue-400 text-sm font-medium">Empowering Digital Growth</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight mb-6">
              Driving Business Impact Through <span className="text-blue-500">Data & Technology</span>
            </h1>
            <p className="text-xl text-slate-300 mb-10 leading-relaxed">
              Riveting Data Consult Limited provides world-class consulting and digital solutions 
              to help startups, SMEs, and government programs scale with automation and actionable insights.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/contact">
                <Button size="lg" className="w-full sm:w-auto h-auto py-3.5">Get a Consultation</Button>
              </Link>
              <Link to="/services">
                <Button variant="outline" size="lg" className="w-full sm:w-auto h-auto py-3.5 border-white text-white hover:bg-white hover:text-slate-900">
                  Explore Services
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-blue-600 font-semibold tracking-wide uppercase text-sm mb-3">Our Expertise</h2>
            <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Comprehensive Solutions for Modern Challenges</h3>
            <p className="text-slate-600">We bridge the gap between complex technology and business success.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-8 rounded-2xl bg-slate-50 border border-slate-100 hover:shadow-xl hover:-translate-y-1 transition-all group"
              >
                <div className="mb-6 p-3 bg-white rounded-xl shadow-sm inline-block group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  {React.cloneElement(service.icon as React.ReactElement<{ className?: string }>, { className: 'group-hover:text-white' })}
                </div>
                <h4 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h4>
                <p className="text-slate-600 mb-6 leading-relaxed">{service.description}</p>
                <Link to="/services" className="text-blue-600 font-medium flex items-center hover:underline">
                  Learn More <ArrowRight size={16} className="ml-2" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2">
              <img 
                src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/data-analytics-81a9cd5c-1775109994216.webp" 
                alt="Data-driven consulting" 
                className="rounded-3xl shadow-2xl"
              />
            </div>
            <div className="lg:w-1/2 space-y-8">
              <div>
                <h2 className="text-blue-600 font-semibold tracking-wide uppercase text-sm mb-3">Why Partner With Us</h2>
                <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">Expertise Built on Trust and Tangible Results</h3>
              </div>

              <div className="grid gap-6">
                {[
                  {
                    title: 'Data-Driven Approach',
                    desc: "We don't guess. We use data to inform every strategy and technical decision.",
                    icon: <BarChart3 className="text-blue-600" />
                  },
                  {
                    title: 'Impact-Focused',
                    desc: 'Our solutions are designed to deliver measurable social and economic impact.',
                    icon: <Zap className="text-blue-600" />
                  },
                  {
                    title: 'Industry Experts',
                    desc: 'Deep experience across Microsoft technology ecosystems and SME development.',
                    icon: <ShieldCheck className="text-blue-600" />
                  },
                ].map((item, idx) => (
                  <div key={idx} className="flex items-start space-x-4">
                    <div className="mt-1 p-2 bg-blue-100 rounded-lg text-blue-600">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 mb-1">{item.title}</h4>
                      <p className="text-slate-600">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Academy CTA */}
      <section className="py-24 bg-blue-600 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-blue-500 transform skew-x-12 translate-x-1/2" />
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-3xl">
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Riveting Digital Academy</h2>
            <p className="text-xl text-blue-100 mb-10 leading-relaxed">
              Bridging the skills gap through Microsoft technology training, workforce development, 
              and education-to-employment pathways.
            </p>
            <Link to="/academy">
              <Button variant="secondary" size="lg" className="bg-white text-blue-600 hover:bg-blue-50 border-none h-auto py-3.5">
                Learn Digital Skills
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-white text-center">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto p-12 rounded-3xl bg-slate-900 text-white">
            <h2 className="text-3xl font-bold mb-6">Ready to scale your organization?</h2>
            <p className="text-slate-400 mb-8 text-lg">
              Let&apos;s discuss how our consulting and technology solutions can drive your growth.
            </p>
            <Link to="/contact">
              <Button size="lg" className="px-10 h-auto py-3.5">Schedule a Free Call</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;