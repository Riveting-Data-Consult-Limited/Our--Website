import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

export function CTASection() {
  return (
    <section className="py-24 bg-blue-600 overflow-hidden relative">
      {/* Decorative Circles */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500 rounded-full translate-x-1/2 -translate-y-1/2 blur-3xl opacity-50" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-700 rounded-full -translate-x-1/2 translate-y-1/2 blur-3xl opacity-50" />

      <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-8 leading-tight">
            Ready to Accelerate Your <span className="text-blue-200">Digital Transformation?</span>
          </h2>
          <p className="text-blue-100 text-lg md:text-xl mb-12 opacity-90 max-w-2xl mx-auto">
            Join the forward-thinking organizations leveraging Riveting Data Consult for sustainable growth and technical excellence.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <Link
              to="/contact"
              className="w-full sm:w-auto px-10 py-5 bg-white text-blue-600 rounded-2xl font-bold text-lg hover:bg-blue-50 transition-all shadow-xl shadow-blue-900/20"
            >
              Book a Consultation
            </Link>
            <Link
              to="/services"
              className="w-full sm:w-auto px-10 py-5 bg-blue-700 text-white border border-blue-500 rounded-2xl font-bold text-lg hover:bg-blue-800 transition-all"
            >
              View Our Services
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}