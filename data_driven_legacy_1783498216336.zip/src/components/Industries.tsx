import React from 'react';
import { 
  Building2, 
  Globe2, 
  HeartHandshake,
  GraduationCap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const Industries = () => {
  const sectors = [
    {
      title: 'Startups & Entrepreneurs',
      desc: 'Helping founders build MVPs, register businesses, and scale with data-driven strategies.',
      icon: <Globe2 className="text-blue-600" />,
      benefits: ['Rapid Prototype Development', 'Go-to-Market Strategy', 'Business Documentation']
    },
    {
      title: 'SMEs & Growing Businesses',
      desc: 'Optimizing operations through automation and enhancing brand presence for market dominance.',
      icon: <Building2 className="text-blue-600" />,
      benefits: ['Process Automation', 'Digital Marketing ROI', 'Workflow Efficiency']
    },
    {
      title: 'Government & Public Sector',
      desc: 'Supporting digital transformation initiatives and public program management.',
      icon: <Building2 className="text-slate-900" />,
      benefits: ['Data Management Systems', 'Capacity Building Programs', 'Digital Governance']
    },
    {
      title: 'NGOs & Dev Partners',
      desc: 'Leveraging technology to measure impact and drive social change initiatives.',
      icon: <HeartHandshake className="text-blue-600" />,
      benefits: ['Impact Measurement Tools', 'Community Engagement Platforms', 'Grant Support Technology']
    },
    {
      title: 'Educational Institutions',
      desc: 'Transforming traditional learning environments with modern EdTech solutions.',
      icon: <GraduationCap className="text-blue-600" />,
      benefits: ['LMS Implementation', 'Digital Literacy for Staff', 'Student Data Portals']
    }
  ];

  return (
    <div className="pt-24">
      {/* Header */}
      <section className="bg-slate-50 py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">Who We Serve</h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              Our expertise spans across diverse sectors, providing tailored solutions that 
              address the specific challenges of startups, government, and education.
            </p>
          </div>
        </div>
      </section>

      {/* Sectors */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="space-y-16">
            {sectors.map((sector, idx) => (
              <div key={idx} className={`flex flex-col lg:flex-row items-center gap-12 ${idx % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
                <div className="lg:w-1/2">
                  <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mb-6">
                    {React.cloneElement(sector.icon as React.ReactElement<{ size?: number }>, { size: 32 })}
                  </div>
                  <h2 className="text-3xl font-bold text-slate-900 mb-4">{sector.title}</h2>
                  <p className="text-lg text-slate-600 mb-8">{sector.desc}</p>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                    {sector.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-center text-slate-700 font-medium">
                        <div className="w-2 h-2 bg-blue-600 rounded-full mr-3" />
                        {benefit}
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact">
                    <Button variant="outline">Learn More</Button>
                  </Link>
                </div>
                <div className="lg:w-1/2 w-full h-80 bg-slate-100 rounded-3xl overflow-hidden shadow-inner flex items-center justify-center border border-slate-200">
                   <div className="text-slate-400 font-medium italic">Industry Specific Solutions</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Impact */}
      <section className="py-24 bg-slate-900 text-white">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-8">Driving Systemic Impact</h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto mb-12">
            Beyond business growth, we are committed to youth development, women empowerment, 
            and enhancing the Nigerian digital ecosystem through strategic partnerships.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 bg-slate-800 rounded-2xl">
              <h3 className="text-2xl font-bold text-blue-400 mb-2">Youth</h3>
              <p className="text-slate-400">Digital literacy programs and workforce readiness.</p>
            </div>
            <div className="p-8 bg-slate-800 rounded-2xl">
              <h3 className="text-2xl font-bold text-blue-400 mb-2">Women</h3>
              <p className="text-slate-400">Targeted tech inclusion and entrepreneurship support.</p>
            </div>
            <div className="p-8 bg-slate-800 rounded-2xl">
              <h3 className="text-2xl font-bold text-blue-400 mb-2">Public</h3>
              <p className="text-slate-400">Modernizing governance through data transparency.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Industries;