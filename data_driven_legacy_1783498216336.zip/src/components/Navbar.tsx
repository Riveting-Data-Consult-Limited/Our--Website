import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Services', path: '/services' },
    { name: 'Academy', path: '/academy' },
    { name: 'Industries', path: '/industries' },
    { name: 'Contact', path: '/contact' },
  ];

  const logoUrl = "https://storage.googleapis.com/dala-prod-public-storage/attachments/468e8d18-7b75-4c1e-9971-d2e7bc2ceab5/1775162090522_Riveting_Data_Consult_Updated_Logo.png";

  return (
    <nav
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
        scrolled ? 'bg-white/95 backdrop-blur-md shadow-md py-2' : 'bg-transparent py-4'
      )}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center">
            <img 
              src={logoUrl} 
              alt="Riveting Data Consult Logo" 
              className={cn("transition-all duration-300", scrolled ? 'h-10 md:h-12' : 'h-12 md:h-14')}
              style={{ filter: !scrolled ? 'brightness(0) invert(1)' : 'none' }}
            />
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  'text-sm font-bold transition-colors hover:text-blue-500',
                  scrolled ? 'text-slate-600' : 'text-slate-800 md:text-white',
                  location.pathname === link.path && 'text-blue-600 md:text-blue-400'
                )}
              >
                {link.name}
              </Link>
            ))}
            <Link to="/contact">
              <Button size="sm" variant={scrolled ? 'default' : 'outline'} className={!scrolled ? 'border-white text-white hover:bg-white hover:text-blue-600' : ''}>
                Consult Now
              </Button>
            </Link>
          </div>

          {/* Mobile Toggle */}
          <button
            className={cn("md:hidden", scrolled ? "text-slate-900" : "text-white")}
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={cn(
          'fixed inset-0 top-[64px] bg-white z-40 transition-transform duration-300 md:hidden',
          isOpen ? 'translate-x-0' : 'translate-x-full'
        )}
      >
        <div className="flex flex-col p-6 space-y-6">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={cn(
                'text-xl font-bold flex items-center justify-between',
                location.pathname === link.path ? 'text-blue-600' : 'text-slate-800'
              )}
            >
              {link.name}
              <ChevronRight size={20} className="text-slate-400" />
            </Link>
          ))}
          <Link to="/contact">
            <Button className="w-full py-4 text-lg h-auto">Book a Consultation</Button>
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;