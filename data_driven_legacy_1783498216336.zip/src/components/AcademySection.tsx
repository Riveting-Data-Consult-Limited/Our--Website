import { motion } from 'framer-motion';
import { BookOpen, Award, Users, GraduationCap, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const stats = [
  { label: 'Microsoft Certified', icon: Award, color: 'text-blue-500', bg: 'bg-blue-50' },
  { label: 'Digital Skills Training', icon: BookOpen, color: 'text-emerald-500', bg: 'bg-emerald-50' },
  { label: 'Workforce Development', icon: Users, color: 'text-orange-500', bg: 'bg-orange-50' },
  { label: 'Entrepreneurship Pathways', icon: GraduationCap, color: 'text-purple-500', bg: 'bg-purple-50' },
];

export function AcademySection() {
  return (
    <section className="py-24 bg-slate-50 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/2 h-full bg-blue-600/5 -skew-x-12 translate-x-1/2 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-6 relative">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-600"></span>
              </span>
              <span>Riveting Digital Academy</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 leading-tight">
              Future-Proof Your <span className="text-blue-600">Career & Workforce</span>
            </h2>
            <p className="text-slate-600 text-lg mb-8 leading-relaxed">
              We deliver cutting-edge digital skills, Microsoft technology training, and EdTech solutions designed to bridge the skills gap and foster economic growth.
            </p>

            <div className="grid grid-cols-2 gap-6 mb-10">
              {stats.map((stat, idx) => (
                <div key={idx} className="flex items-center space-x-3">
                  <div className={`w-10 h-10 ${stat.bg} ${stat.color} rounded-lg flex items-center justify-center`}>
                    <stat.icon size={20} />
                  </div>
                  <span className="text-sm font-semibold text-slate-700">{stat.label}</span>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link 
                to="/academy" 
                className="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 flex items-center justify-center group"
              >
                Explore Programs
                <ChevronRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link 
                to="/contact" 
                className="bg-white text-slate-900 border border-slate-200 px-8 py-4 rounded-xl font-bold hover:bg-slate-50 transition-all flex items-center justify-center"
              >
                Partner With Us
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl z-10">
              <img 
                src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/edbffca7-2e07-4701-adf7-ca74210c78ee/digital-academy-image-a02cf90d-1775109574190.webp" 
                alt="Digital Academy Training" 
                className="w-full aspect-[4/5] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent flex items-end p-8">
                <div className="text-white">
                  <div className="text-3xl font-bold mb-2">95%</div>
                  <div className="text-blue-200 text-sm font-medium uppercase tracking-wider">Employment Rate Post-Training</div>
                </div>
              </div>
            </div>
            
            {/* Floating Card */}
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl z-20 hidden sm:block max-w-[240px]">
              <div className="flex items-center space-x-4 mb-3">
                <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                  <GraduationCap size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Skills First</h4>
                  <p className="text-[10px] text-slate-500 font-medium">Industry Aligned Curriculum</p>
                </div>
              </div>
              <p className="text-xs text-slate-600 italic">"Empowering the next generation of Nigerian tech leaders."</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}