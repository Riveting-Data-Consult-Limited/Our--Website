import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MessageSquare, Send, ExternalLink, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    service: 'Consulting',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Message sent! We will get back to you shortly.');
    setFormData({ name: '', email: '', service: 'Consulting', message: '' });
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent("Hello Riveting Data Consult, I'd like to discuss a potential project.");
    window.open(`https://wa.me/2347068871897?text=${text}`, '_blank');
  };

  return (
    <div className="pt-24">
      {/* Header */}
      <section className="bg-white py-20 border-b border-slate-100">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-2xl">
            <h1 className="text-4xl font-bold text-slate-900 mb-4">Let&apos;s Build Something Great</h1>
            <p className="text-xl text-slate-600">
              Ready to take your organization to the next level? Our team is here to help you 
              navigate the digital landscape.
            </p>
          </div>
        </div>
      </section>

      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col lg:flex-row gap-16">
            {/* Contact Form */}
            <div className="lg:w-3/5">
              <div className="bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-slate-200">
                <h2 className="text-2xl font-bold text-slate-900 mb-8">Send us a Message</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-slate-700">Your Name</label>
                      <input 
                        required
                        type="text" 
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        placeholder="John Doe"
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-slate-700">Email Address</label>
                      <input 
                        required
                        type="email" 
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        placeholder="john@example.com"
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-700">Inquiry Type</label>
                    <select 
                      value={formData.service}
                      onChange={(e) => setFormData({...formData, service: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                    >
                      <option>Business Consulting</option>
                      <option>Software Development</option>
                      <option>Data Analytics</option>
                      <option>Digital Academy / Training</option>
                      <option>Registration & Compliance</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-700">Your Message</label>
                    <textarea 
                      required
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      placeholder="Tell us about your project or inquiry..."
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                    />
                  </div>
                  <Button type="submit" size="lg" className="w-full h-auto py-3.5">
                    <Send size={18} className="mr-2" />
                    Send Message
                  </Button>
                </form>
              </div>
            </div>

            {/* Contact Info */}
            <div className="lg:w-2/5 space-y-8">
              <div className="p-8 rounded-3xl bg-blue-600 text-white shadow-xl">
                <h3 className="text-2xl font-bold mb-6">Quick Contact</h3>
                <div className="space-y-6">
                  <a href="mailto:cchukwuwike@riveting-group.com.ng" className="flex items-start space-x-4 group">
                    <div className="w-10 h-10 rounded-full bg-blue-500/50 flex items-center justify-center shrink-0 group-hover:bg-white group-hover:text-blue-600 transition-all">
                      <Mail size={20} />
                    </div>
                    <div>
                      <p className="text-sm text-blue-100 font-medium">Email Address</p>
                      <p className="font-semibold break-all">cchukwuwike@riveting-group.com.ng</p>
                    </div>
                  </a>
                  <a href="tel:+2347068871897" className="flex items-start space-x-4 group">
                    <div className="w-10 h-10 rounded-full bg-blue-500/50 flex items-center justify-center shrink-0 group-hover:bg-white group-hover:text-blue-600 transition-all">
                      <Phone size={20} />
                    </div>
                    <div>
                      <p className="text-sm text-blue-100 font-medium">Phone Number</p>
                      <p className="font-semibold">+234 706 887 1897</p>
                    </div>
                  </a>
                  <button onClick={handleWhatsApp} className="flex items-start space-x-4 group text-left">
                    <div className="w-10 h-10 rounded-full bg-blue-500/50 flex items-center justify-center shrink-0 group-hover:bg-white group-hover:text-blue-600 transition-all">
                      <MessageSquare size={20} />
                    </div>
                    <div>
                      <p className="text-sm text-blue-100 font-medium">WhatsApp</p>
                      <p className="font-semibold">Chat with an Expert</p>
                    </div>
                  </button>
                </div>
              </div>

              <div className="p-8 rounded-3xl bg-white border border-slate-200 shadow-sm">
                <h3 className="text-xl font-bold text-slate-900 mb-6">Follow Us</h3>
                <a 
                  href="https://ng.linkedin.com/company/riveting-data-consult-rdc" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 hover:bg-slate-100 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <Globe className="text-[#0077b5]" size={24} />
                    <span className="font-semibold text-slate-700">LinkedIn Profile</span>
                  </div>
                  <ExternalLink size={18} className="text-slate-400" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;