import { ExternalLink, Mail, Phone, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const logoUrl = "https://storage.googleapis.com/dala-prod-public-storage/attachments/468e8d18-7b75-4c1e-9971-d2e7bc2ceab5/1775162090522_Riveting_Data_Consult_Updated_Logo.png";

  return (
    <footer className="bg-slate-950 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Company Info */}
          <div className="space-y-6">
            <Link to="/" className="inline-block">
              <img 
                src={logoUrl} 
                alt="Riveting Data Consult Logo" 
                className="h-12 w-auto brightness-0 invert opacity-90 hover:opacity-100 transition-opacity"
              />
            </Link>
            <p className="text-slate-400 text-sm leading-relaxed max-w-xs">
              Empowering startups, SMEs, and institutions through technology, data-driven insights, and strategic consulting. Based in Nigeria, serving the world.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://ng.linkedin.com/company/riveting-data-consult-rdc"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-slate-800 p-2 rounded-full hover:bg-blue-600 transition-colors"
              >
                <ExternalLink size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-white">Quick Links</h3>
            <ul className="space-y-4">
              <li><Link to="/" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium">Home</Link></li>
              <li><Link to="/about" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium">About Us</Link></li>
              <li><Link to="/services" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium">Services</Link></li>
              <li><Link to="/academy" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium">Digital Academy</Link></li>
              <li><Link to="/contact" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium">Contact Us</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-white">Expertise</h3>
            <ul className="space-y-4">
              <li><Link to="/services" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium">Software Development</Link></li>
              <li><Link to="/services" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium">Data Analytics</Link></li>
              <li><Link to="/services" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium">AI & Automations</Link></li>
              <li><Link to="/services" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium">Business Strategy</Link></li>
              <li><Link to="/services" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium">Microsoft Trainings</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-white">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <Mail size={18} className="text-blue-400 mt-1 shrink-0" />
                <a href="mailto:cchukwuwike@riveting-group.com.ng" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium break-all">
                  cchukwuwike@riveting-group.com.ng
                </a>
              </li>
              <li className="flex items-start space-x-3">
                <Phone size={18} className="text-blue-400 mt-1 shrink-0" />
                <a href="tel:+2347068871897" className="text-slate-400 hover:text-blue-400 transition-colors text-sm font-medium">
                  +234 706 887 1897
                </a>
              </li>
              <li className="flex items-start space-x-3">
                <MapPin size={18} className="text-blue-400 mt-1 shrink-0" />
                <span className="text-slate-400 text-sm font-medium">Lagos, Nigeria</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center text-sm text-slate-500 font-medium">
          <p>\u00a9 {new Date().getFullYear()} Riveting Data Consult Limited. All rights reserved.</p>
          <div className="mt-4 md:mt-0 space-x-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;